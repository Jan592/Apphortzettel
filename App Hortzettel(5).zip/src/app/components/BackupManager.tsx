import { useState, useEffect, useRef, useCallback } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Badge } from "./ui/badge";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "./ui/tooltip";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import {
  Cloud,
  Download,
  Upload,
  Trash2,
  Clock,
  CheckCircle2,
  XCircle,
  AlertCircle,
  FolderOpen,
  Folder,
  Calendar,
  HardDrive,
  Settings,
  Loader2,
  FileJson,
  Info,
  Copy,
  Check,
  Link,
  ExternalLink,
  Pencil,
  X,
  RefreshCw,
  Wifi,
  WifiOff,
} from "lucide-react";
import { toast } from "sonner";
import type { BackupRecord } from "../utils/backupService";
import {
  collectBackupData,
  createBackupBlob,
  generateBackupFileName,
  downloadBackupLocally,
  getBackupHistory,
  addBackupRecord,
  updateBackupRecord,
  getLastAutoBackupDate,
  setLastAutoBackupDate,
  isAutoBackupEnabled,
  setAutoBackupEnabled,
  formatBytes,
  formatDate,
} from "../utils/backupService";
import type { UploadedFile } from "../utils/googleDriveService";
import {
  APPS_SCRIPT_CODE,
  getScriptUrl,
  setScriptUrl,
  clearScriptUrl,
  isConfigured,
  getScriptFolder,
  setScriptFolder,
  getDriveFolderSearchUrl,
  uploadViaAppScript,
  testScriptConnection,
  getUploadedFiles,
  removeUploadedFile,
} from "../utils/googleDriveService";

// ─── Kleiner Code-Block mit Copy-Button ───────────────────────────────────────
function CodeBlock({ code }: { code: string }) {
  const [copied, setCopied] = useState(false);
  const handleCopy = () => {
    navigator.clipboard.writeText(code).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };
  return (
    <div className="relative">
      <pre className="bg-slate-900 text-slate-100 text-xs rounded-lg p-4 overflow-x-auto max-h-56 overflow-y-auto leading-relaxed font-mono whitespace-pre">{code}</pre>
      <Tooltip>
        <TooltipTrigger asChild>
          <button
            onClick={handleCopy}
            className="absolute top-2 right-2 p-1.5 rounded bg-slate-700 hover:bg-slate-600 text-slate-300 hover:text-white transition-colors"
          >
            {copied ? <Check className="h-3.5 w-3.5 text-green-400" /> : <Copy className="h-3.5 w-3.5" />}
          </button>
        </TooltipTrigger>
        <TooltipContent>{copied ? "Kopiert!" : "Code kopieren"}</TooltipContent>
      </Tooltip>
    </div>
  );
}

// ─── Hauptkomponente ──────────────────────────────────────────────────────────
export default function BackupManager() {
  const [configured, setConfigured] = useState(isConfigured());
  const [scriptUrl, setScriptUrlState] = useState(getScriptUrl());
  const [folderName, setFolderNameState] = useState(getScriptFolder());
  const [editingUrl, setEditingUrl] = useState(false);
  const [tempUrl, setTempUrl] = useState(getScriptUrl());
  const [tempFolder, setTempFolder] = useState(getScriptFolder());
  const [editingFolder, setEditingFolder] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState<'unknown' | 'ok' | 'error'>('unknown');
  const [testingConnection, setTestingConnection] = useState(false);

  const [autoBackupEnabled, setAutoBackupEnabledState] = useState(isAutoBackupEnabled());
  const [lastBackupDate, setLastBackupDate] = useState<string | null>(getLastAutoBackupDate());
  const [backupHistory, setBackupHistory] = useState<BackupRecord[]>(getBackupHistory());
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>(getUploadedFiles());
  const [isBackingUp, setIsBackingUp] = useState(false);
  const [nextBackupIn, setNextBackupIn] = useState("");

  const [showSetupDialog, setShowSetupDialog] = useState(false);
  const [setupStep, setSetupStep] = useState(0);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const refreshHistory = useCallback(() => {
    setBackupHistory(getBackupHistory());
    setLastBackupDate(getLastAutoBackupDate());
    setUploadedFiles(getUploadedFiles());
  }, []);

  // Countdown
  useEffect(() => {
    const tick = () => {
      const now = new Date();
      const next = new Date(now);
      next.setHours(2, 0, 0, 0);
      if (next <= now) next.setDate(next.getDate() + 1);
      const d = next.getTime() - now.getTime();
      const h = Math.floor(d / 3600000);
      const m = Math.floor((d % 3600000) / 60000);
      const s = Math.floor((d % 60000) / 1000);
      setNextBackupIn(`${h}h ${m}m ${s}s`);
    };
    tick();
    const t = setInterval(tick, 1000);
    return () => clearInterval(t);
  }, []);

  // Verbindungstest
  const handleTestConnection = useCallback(async () => {
    if (!isConfigured()) return;
    setTestingConnection(true);
    setConnectionStatus('unknown');
    try {
      const ok = await testScriptConnection();
      setConnectionStatus(ok ? 'ok' : 'error');
      if (ok) {
        toast.success("Verbindung zum Apps Script erfolgreich");
      } else {
        toast.error("Apps Script nicht erreichbar – URL prüfen");
      }
    } catch {
      setConnectionStatus('error');
      toast.error("Verbindungstest fehlgeschlagen");
    } finally {
      setTestingConnection(false);
    }
  }, []);

  // ─── URL speichern ──────────────────────────────────────────────────────────
  const handleSaveUrl = () => {
    const url = tempUrl.trim();
    if (!url.startsWith("https://script.google.com/macros/")) {
      toast.error("Bitte eine gueltige Apps Script URL einfuegen (beginnt mit https://script.google.com/macros/)");
      return;
    }
    setScriptUrl(url);
    setScriptUrlState(url);
    setConfigured(true);
    setEditingUrl(false);
    setShowSetupDialog(false);
    setConnectionStatus('unknown');
    toast.success("Apps Script URL gespeichert!");
  };

  const handleClearUrl = () => {
    if (!confirm("Script-URL entfernen? Backups auf Drive werden deaktiviert.")) return;
    clearScriptUrl();
    setScriptUrlState("");
    setConfigured(false);
    setConnectionStatus('unknown');
    toast.info("Script-URL entfernt");
  };

  // ─── Ordnername speichern ───────────────────────────────────────────────────
  const handleSaveFolder = () => {
    const name = tempFolder.trim() || "Hortzettel Backups";
    setScriptFolder(name);
    setFolderNameState(name);
    setEditingFolder(false);
    toast.success(`Ordner gesetzt: "${name}"`);
  };

  // ─── Backup ausführen ───────────────────────────────────────────────────────
  const runBackup = useCallback(async (type: "auto" | "manual") => {
    if (isBackingUp) return;
    setIsBackingUp(true);

    const record: BackupRecord = {
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      type,
      size: 0,
      status: "pending",
    };
    addBackupRecord(record);
    refreshHistory();

    try {
      const data = collectBackupData();
      const blob = createBackupBlob(data);
      const fileName = generateBackupFileName();

      if (isConfigured()) {
        const text = await blob.text();
        await uploadViaAppScript(text, fileName);
        updateBackupRecord(record.id, { status: "success", size: blob.size });
        if (type === "auto") setLastAutoBackupDate(new Date().toISOString().split("T")[0]);
        toast.success(`Backup gesendet: ${fileName}`, {
          description: `Ordner: "${getScriptFolder()}" in Google Drive`,
        });
      } else {
        downloadBackupLocally(data);
        updateBackupRecord(record.id, { status: "success", size: blob.size });
        if (type === "auto") setLastAutoBackupDate(new Date().toISOString().split("T")[0]);
        toast.success(`Backup lokal heruntergeladen: ${fileName}`);
      }
    } catch (e) {
      console.error("[BackupManager] Backup fehlgeschlagen:", e);
      updateBackupRecord(record.id, { status: "failed" });
      toast.error(`Backup fehlgeschlagen: ${e instanceof Error ? e.message : String(e)}`);
    } finally {
      setIsBackingUp(false);
      refreshHistory();
    }
  }, [isBackingUp, refreshHistory]);

  const handleToggleAutoBackup = (val: boolean) => {
    setAutoBackupEnabled(val);
    setAutoBackupEnabledState(val);
    toast.success(val ? "Auto-Backup aktiviert (taeglich 02:00 Uhr)" : "Auto-Backup deaktiviert");
  };

  const handleDeleteUploadedFile = (id: string) => {
    removeUploadedFile(id);
    setUploadedFiles(getUploadedFiles());
    toast.info("Eintrag entfernt (Datei bleibt in Drive)");
  };

  const handleUploadLocal = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const content = e.target?.result as string;
        JSON.parse(content); // validieren
        await uploadViaAppScript(content, file.name);
        toast.success(`Datei hochgeladen: ${file.name}`);
        refreshHistory();
      } catch (ex) {
        toast.error(`Upload fehlgeschlagen: ${ex instanceof Error ? ex.message : String(ex)}`);
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const statusIcon = (s: BackupRecord["status"]) =>
    s === "success" ? <CheckCircle2 className="h-4 w-4 text-green-500" /> :
    s === "failed"  ? <XCircle      className="h-4 w-4 text-red-500"   /> :
                      <Loader2      className="h-4 w-4 text-yellow-500 animate-spin" />;

  const statusBadge = (s: BackupRecord["status"]) =>
    s === "success" ? <Badge className="bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400 border-0">Erfolgreich</Badge> :
    s === "failed"  ? <Badge className="bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400 border-0">Fehlgeschlagen</Badge> :
                      <Badge className="bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400 border-0">Ausstehend</Badge>;

  // ─── Setup-Dialog Schritte ──────────────────────────────────────────────────
  const SETUP_STEPS = [
    {
      title: "Google Apps Script öffnen",
      icon: ExternalLink,
      desc: (
        <span>
          Gehe zu{" "}
          <a href="https://script.google.com" target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline inline-flex items-center gap-1">
            script.google.com <ExternalLink className="h-3 w-3" />
          </a>{" "}
          und melde dich mit deinem Google-Konto an.
        </span>
      ),
    },
    {
      title: "Code einfügen",
      icon: FileJson,
      desc: (
        <span>
          Klicke auf <strong>Neues Projekt</strong>. Loesche den vorhandenen Code vollstaendig und fuege den folgenden Code ein:
        </span>
      ),
      extra: <CodeBlock code={APPS_SCRIPT_CODE} />,
    },
    {
      title: "Als Web App deployen",
      icon: Cloud,
      desc: (
        <span>
          Klicke oben rechts auf <strong>Deployen</strong> &rarr; <strong>Neue Bereitstellung</strong>.
          Typ: <strong>Web App</strong>.
          &bdquo;Ausfuehren als&ldquo;: <strong>Ich</strong>.
          &bdquo;Zugriff&ldquo;: <strong>Jeder</strong>.
          Klicke <strong>Bereitstellen</strong> und kopiere die Web-App-URL.
        </span>
      ),
    },
    {
      title: "URL hier einfügen",
      icon: Link,
      desc: <span>Fuege die Web-App-URL unten ein und klicke auf Speichern.</span>,
      extra: (
        <div className="space-y-3 mt-2">
          <div>
            <Label className="text-xs">Web App URL</Label>
            <Input
              className="mt-1 font-mono text-xs"
              placeholder="https://script.google.com/macros/s/.../exec"
              value={tempUrl}
              onChange={e => setTempUrl(e.target.value)}
            />
          </div>
          <Button className="w-full" onClick={handleSaveUrl}>
            <CheckCircle2 className="h-4 w-4 mr-2" /> Speichern & fertig
          </Button>
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6">

      {/* ── Header ─────────────────────────────────────────────────────────────── */}
      <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md p-6 border">
        <div className="flex items-center justify-between flex-wrap gap-3 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center shadow">
              <HardDrive className="h-5 w-5 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-lg">Tägliches Backup</h3>
              <p className="text-sm text-muted-foreground">Alle Daten – Benutzer, Hortzettel, Einstellungen</p>
            </div>
          </div>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="ghost" size="icon" onClick={() => { setSetupStep(0); setShowSetupDialog(true); }}>
                <Info className="h-5 w-5 text-muted-foreground" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Einrichtungsanleitung anzeigen</TooltipContent>
          </Tooltip>
        </div>

        {/* Status-Kacheln */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {/* Auto-Backup */}
          <div className="bg-slate-50 dark:bg-slate-700/40 rounded-lg p-4 border">
            <div className="flex items-center gap-2 mb-2">
              <Clock className="h-4 w-4 text-blue-500" />
              <span className="text-sm font-medium">Auto-Backup</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground">täglich 02:00 Uhr</span>
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => handleToggleAutoBackup(!autoBackupEnabled)}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${autoBackupEnabled ? "bg-blue-500" : "bg-slate-300 dark:bg-slate-600"}`}
                  >
                    <span className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform ${autoBackupEnabled ? "translate-x-6" : "translate-x-1"}`} />
                  </button>
                </TooltipTrigger>
                <TooltipContent>{autoBackupEnabled ? "Deaktivieren" : "Aktivieren"}</TooltipContent>
              </Tooltip>
            </div>
            {autoBackupEnabled && (
              <p className="text-xs text-blue-600 dark:text-blue-400 mt-2">Naechstes Backup in: {nextBackupIn}</p>
            )}
          </div>

          {/* Letztes Backup */}
          <div className="bg-slate-50 dark:bg-slate-700/40 rounded-lg p-4 border">
            <div className="flex items-center gap-2 mb-2">
              <Calendar className="h-4 w-4 text-green-500" />
              <span className="text-sm font-medium">Letztes Backup</span>
            </div>
            {lastBackupDate ? (
              <p className="text-xs text-green-600 dark:text-green-400 font-medium">{formatDate(lastBackupDate + "T00:00:00")}</p>
            ) : (
              <p className="text-xs text-muted-foreground">Noch kein Backup</p>
            )}
          </div>

          {/* Drive Status */}
          <div className="bg-slate-50 dark:bg-slate-700/40 rounded-lg p-4 border">
            <div className="flex items-center gap-2 mb-2">
              <Cloud className={`h-4 w-4 ${configured ? "text-green-500" : "text-slate-400"}`} />
              <span className="text-sm font-medium">Google Drive</span>
            </div>
            {configured ? (
              <div className="space-y-1.5">
                <div className="flex items-center gap-2">
                  <Badge className="bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400 border-0 text-xs">Eingerichtet</Badge>
                  {connectionStatus === 'ok'    && <Wifi    className="h-3.5 w-3.5 text-green-500" />}
                  {connectionStatus === 'error' && <WifiOff className="h-3.5 w-3.5 text-red-500"   />}
                </div>
                <p className="text-xs text-muted-foreground truncate">{folderName}</p>
              </div>
            ) : (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button size="sm" variant="outline" className="h-7 text-xs w-full" onClick={() => { setSetupStep(0); setShowSetupDialog(true); }}>
                    <Settings className="h-3 w-3 mr-1" /> Einrichten
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Google Drive einrichten (kein Client ID nötig)</TooltipContent>
              </Tooltip>
            )}
          </div>
        </div>
      </div>

      {/* ── Ziel-Ordner ────────────────────────────────────────────────────────── */}
      <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md p-6 border">
        <div className="flex items-center justify-between mb-4">
          <h4 className="font-medium flex items-center gap-2">
            <Folder className="h-4 w-4 text-yellow-500" />
            Ziel-Ordner in Google Drive
          </h4>
          <div className="flex gap-2">
            {configured && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <a href={getDriveFolderSearchUrl()} target="_blank" rel="noopener noreferrer">
                    <Button variant="outline" size="sm">
                      <ExternalLink className="h-3.5 w-3.5 mr-1" /> In Drive öffnen
                    </Button>
                  </a>
                </TooltipTrigger>
                <TooltipContent>Ordner in Google Drive suchen & öffnen</TooltipContent>
              </Tooltip>
            )}
            {!editingFolder && (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="sm" onClick={() => { setTempFolder(folderName); setEditingFolder(true); }}>
                    <Pencil className="h-3.5 w-3.5 mr-1" /> Ändern
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Ordnernamen ändern</TooltipContent>
              </Tooltip>
            )}
          </div>
        </div>

        {editingFolder ? (
          <div className="space-y-3">
            <p className="text-xs text-muted-foreground">
              Gib den Namen des Google Drive Ordners ein. Existiert er noch nicht, wird er automatisch erstellt.
            </p>
            <div className="flex gap-2">
              <Input value={tempFolder} onChange={e => setTempFolder(e.target.value)} placeholder="Hortzettel Backups" />
              <Button onClick={handleSaveFolder}>Speichern</Button>
              <Button variant="ghost" onClick={() => setEditingFolder(false)}><X className="h-4 w-4" /></Button>
            </div>
          </div>
        ) : (
          <div className="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-700/40 rounded-lg border">
            <FolderOpen className="h-5 w-5 text-yellow-500 flex-shrink-0" />
            <div>
              <p className="font-medium text-sm">{folderName}</p>
              <p className="text-xs text-muted-foreground">
                {configured
                  ? "Backups werden in diesem Drive-Ordner gespeichert"
                  : "Ordner wird angelegt sobald das Script eingerichtet ist"}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* ── Script URL ─────────────────────────────────────────────────────────── */}
      <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md p-6 border">
        <div className="flex items-center justify-between mb-4">
          <h4 className="font-medium flex items-center gap-2">
            <Link className="h-4 w-4 text-purple-500" />
            Apps Script URL
          </h4>
          {configured && !editingUrl && (
            <div className="flex gap-2">
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="outline" size="sm" onClick={handleTestConnection} disabled={testingConnection}>
                    {testingConnection ? <Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5 mr-1" />}
                    Testen
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Verbindung zum Apps Script testen</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="sm" onClick={() => { setTempUrl(scriptUrl); setEditingUrl(true); }}>
                    <Pencil className="h-3.5 w-3.5 mr-1" /> Ändern
                  </Button>
                </TooltipTrigger>
                <TooltipContent>URL bearbeiten</TooltipContent>
              </Tooltip>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="ghost" size="sm" className="text-red-500 hover:text-red-700" onClick={handleClearUrl}>
                    <X className="h-3.5 w-3.5" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Script-URL entfernen</TooltipContent>
              </Tooltip>
            </div>
          )}
        </div>

        {!configured && !editingUrl ? (
          <div className="space-y-3">
            <div className="flex items-start gap-3 p-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg">
              <AlertCircle className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-amber-800 dark:text-amber-300">Noch nicht eingerichtet</p>
                <p className="text-xs text-amber-700 dark:text-amber-400 mt-0.5">
                  Richte einmalig ein kostenloses Google Apps Script ein – kein Client ID, kein Cloud Console.
                </p>
              </div>
            </div>
            <Button
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white"
              onClick={() => { setSetupStep(0); setShowSetupDialog(true); }}
            >
              <Settings className="h-4 w-4 mr-2" />
              Jetzt einrichten (3 Minuten)
            </Button>
          </div>
        ) : editingUrl ? (
          <div className="space-y-3">
            <div>
              <Label className="text-xs">Web App URL</Label>
              <Input
                className="mt-1 font-mono text-xs"
                placeholder="https://script.google.com/macros/s/.../exec"
                value={tempUrl}
                onChange={e => setTempUrl(e.target.value)}
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleSaveUrl} className="flex-1">Speichern</Button>
              <Button variant="ghost" onClick={() => setEditingUrl(false)}>Abbrechen</Button>
            </div>
          </div>
        ) : (
          <div className="space-y-2">
            <div className="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-700/40 rounded-lg border">
              <CheckCircle2 className="h-4 w-4 text-green-500 flex-shrink-0" />
              <p className="text-xs font-mono text-muted-foreground truncate flex-1">{scriptUrl}</p>
            </div>
            {connectionStatus === 'ok' && (
              <p className="text-xs text-green-600 dark:text-green-400 flex items-center gap-1">
                <Wifi className="h-3 w-3" /> Script ist erreichbar
              </p>
            )}
            {connectionStatus === 'error' && (
              <p className="text-xs text-red-600 dark:text-red-400 flex items-center gap-1">
                <WifiOff className="h-3 w-3" /> Script nicht erreichbar – URL prüfen
              </p>
            )}
          </div>
        )}
      </div>

      {/* ── Aktionen ───────────────────────────────────────────────────────────── */}
      <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md p-6 border">
        <h4 className="font-medium mb-4 flex items-center gap-2">
          <Settings className="h-4 w-4 text-slate-500" /> Aktionen
        </h4>
        <div className="flex flex-wrap gap-3">
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                onClick={() => runBackup("manual")}
                disabled={isBackingUp}
                className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white shadow"
              >
                {isBackingUp ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <HardDrive className="h-4 w-4 mr-2" />}
                {configured ? "Jetzt auf Drive sichern" : "Lokal herunterladen"}
              </Button>
            </TooltipTrigger>
            <TooltipContent>{configured ? "Backup sofort auf Google Drive senden" : "Backup als JSON-Datei herunterladen"}</TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="outline" onClick={() => downloadBackupLocally(collectBackupData())}>
                <Download className="h-4 w-4 mr-2" /> Lokal herunterladen
              </Button>
            </TooltipTrigger>
            <TooltipContent>Backup als JSON-Datei speichern</TooltipContent>
          </Tooltip>

          {configured && (
            <>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button variant="outline" onClick={() => fileInputRef.current?.click()}>
                    <Upload className="h-4 w-4 mr-2" /> Datei hochladen
                  </Button>
                </TooltipTrigger>
                <TooltipContent>Vorhandene JSON-Backup-Datei auf Drive hochladen</TooltipContent>
              </Tooltip>
              <input ref={fileInputRef} type="file" accept=".json" className="hidden" onChange={handleUploadLocal} />
            </>
          )}
        </div>
      </div>

      {/* ── Auf Drive hochgeladene Dateien ─────────────────────────────────────── */}
      {configured && uploadedFiles.length > 0 && (
        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md p-6 border">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-medium flex items-center gap-2">
              <Cloud className="h-4 w-4 text-blue-500" />
              Auf Drive gesendet
            </h4>
            <div className="flex items-center gap-2">
              <Badge variant="secondary">{uploadedFiles.length} Dateien</Badge>
              <Tooltip>
                <TooltipTrigger asChild>
                  <a href={getDriveFolderSearchUrl()} target="_blank" rel="noopener noreferrer">
                    <Button variant="ghost" size="sm">
                      <ExternalLink className="h-3.5 w-3.5 mr-1" /> Drive öffnen
                    </Button>
                  </a>
                </TooltipTrigger>
                <TooltipContent>Ordner in Google Drive öffnen</TooltipContent>
              </Tooltip>
            </div>
          </div>

          <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-3 mb-3">
            <p className="text-xs text-blue-700 dark:text-blue-300 flex items-start gap-2">
              <Info className="h-3.5 w-3.5 flex-shrink-0 mt-0.5" />
              Die Dateien liegen in deinem Google Drive. Klicke auf &bdquo;Drive öffnen&ldquo; um sie zu verwalten. Das Entfernen hier löscht nur den lokalen Eintrag.
            </p>
          </div>

          <div className="space-y-2 max-h-64 overflow-y-auto">
            {uploadedFiles.map(file => (
              <div key={file.id} className="flex items-center justify-between gap-3 p-3 rounded-lg bg-slate-50 dark:bg-slate-700/40 border">
                <div className="flex items-center gap-3 min-w-0">
                  <FileJson className="h-5 w-5 text-blue-500 flex-shrink-0" />
                  <div className="min-w-0">
                    <p className="text-sm font-medium truncate">{file.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {formatDate(file.uploadedAt)}
                      {file.size > 0 && ` · ${formatBytes(file.size)}`}
                    </p>
                  </div>
                </div>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-slate-400 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20"
                      onClick={() => handleDeleteUploadedFile(file.id)}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>Eintrag entfernen (Datei bleibt in Drive)</TooltipContent>
                </Tooltip>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── Lokaler Verlauf ────────────────────────────────────────────────────── */}
      <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md p-6 border">
        <div className="flex items-center justify-between mb-4">
          <h4 className="font-medium flex items-center gap-2">
            <Clock className="h-4 w-4 text-slate-500" /> Backup-Verlauf
          </h4>
          {backupHistory.length > 0 && <Badge variant="secondary">{backupHistory.length} Einträge</Badge>}
        </div>
        {backupHistory.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <HardDrive className="h-10 w-10 mx-auto mb-3 opacity-30" />
            <p className="text-sm">Noch keine Backups erstellt</p>
          </div>
        ) : (
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {backupHistory.map(rec => (
              <div key={rec.id} className="flex items-center gap-3 p-3 rounded-lg bg-slate-50 dark:bg-slate-700/40 border">
                {statusIcon(rec.status)}
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-medium">{formatDate(rec.createdAt)}</span>
                    <Badge variant="outline" className="text-xs h-5">{rec.type === "auto" ? "Auto" : "Manuell"}</Badge>
                    {rec.driveFileId && (
                      <Badge className="text-xs h-5 bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400 border-0">
                        <Cloud className="h-3 w-3 mr-1" /> Drive
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-2 mt-0.5">
                    {statusBadge(rec.status)}
                    {rec.size > 0 && <span className="text-xs text-muted-foreground">{formatBytes(rec.size)}</span>}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ── Info ───────────────────────────────────────────────────────────────── */}
      <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-xl p-4">
        <div className="flex items-start gap-3">
          <AlertCircle className="h-5 w-5 text-blue-500 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-blue-800 dark:text-blue-300 space-y-1">
            <p className="font-semibold">Was wird gesichert?</p>
            <ul className="space-y-0.5 text-xs">
              <li>Alle 23 Benutzerkonten (inkl. Passwörter)</li>
              <li>Alle 70 Hortzettel-Datensätze</li>
              <li>App-Einstellungen &amp; Design</li>
              <li>Zeitbeschränkungen &amp; Konfiguration</li>
            </ul>
            <p className="text-xs mt-2 text-blue-600 dark:text-blue-400">
              Auto-Backup läuft täglich um 02:00 Uhr (App muss geöffnet sein)
            </p>
          </div>
        </div>
      </div>

      {/* ════ SETUP-DIALOG ════════════════════════════════════════════════════ */}
      <Dialog open={showSetupDialog} onOpenChange={setShowSetupDialog}>
        <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Cloud className="h-5 w-5 text-blue-500" />
              Google Drive einrichten
            </DialogTitle>
            <DialogDescription>
              Einmalige Einrichtung &ndash; kein Client ID, kein Cloud Console nötig.
            </DialogDescription>
          </DialogHeader>

          {/* Schritt-Indikator */}
          <div className="flex items-center gap-1 mb-2">
            {SETUP_STEPS.map((_, i) => (
              <div key={i} className="flex items-center gap-1">
                <button
                  onClick={() => setSetupStep(i)}
                  className={`h-6 w-6 rounded-full text-xs font-bold transition-colors flex items-center justify-center ${
                    i === setupStep
                      ? "bg-blue-500 text-white"
                      : i < setupStep
                      ? "bg-green-500 text-white"
                      : "bg-slate-200 dark:bg-slate-700 text-slate-500"
                  }`}
                >
                  {i < setupStep ? <Check className="h-3 w-3" /> : i + 1}
                </button>
                {i < SETUP_STEPS.length - 1 && (
                  <div className={`h-0.5 w-8 transition-colors ${i < setupStep ? "bg-green-500" : "bg-slate-200 dark:bg-slate-700"}`} />
                )}
              </div>
            ))}
          </div>

          {/* Aktueller Schritt */}
          {(() => {
            const step = SETUP_STEPS[setupStep];
            const Icon = step.icon;
            return (
              <div className="space-y-4">
                <div className="flex items-start gap-3 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                  <div className="w-9 h-9 bg-blue-500 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Icon className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <p className="font-semibold text-blue-900 dark:text-blue-100">
                      Schritt {setupStep + 1}: {step.title}
                    </p>
                    <p className="text-sm text-blue-700 dark:text-blue-300 mt-0.5">{step.desc}</p>
                  </div>
                </div>
                {step.extra && <div>{step.extra}</div>}
              </div>
            );
          })()}

          {/* Navigation */}
          <div className="flex gap-2 mt-4">
            {setupStep > 0 && (
              <Button variant="outline" onClick={() => setSetupStep(s => s - 1)} className="flex-1">
                Zurück
              </Button>
            )}
            {setupStep < SETUP_STEPS.length - 1 && (
              <Button onClick={() => setSetupStep(s => s + 1)} className="flex-1">
                Weiter
              </Button>
            )}
            <Button variant="ghost" onClick={() => setShowSetupDialog(false)}>
              Schließen
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}