import { AlertTriangle, X } from "lucide-react";
import { Button } from "./ui/button";

interface ServerCrashBannerProps {
  onClose: () => void;
}

export function ServerCrashBanner({ onClose }: ServerCrashBannerProps) {
  return (
    <div className="w-full bg-gradient-to-r from-red-500 to-orange-500 text-white shadow-lg">
      <div className="max-w-4xl mx-auto px-4 py-3">
        <div className="flex items-start gap-3">
          <AlertTriangle className="h-6 w-6 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <h3 className="font-bold text-lg mb-1">
              ⚠️ Wichtig: Serverabsturz - Passwort zurücksetzen erforderlich
            </h3>
            <p className="text-sm opacity-90">
              Nach dem Serverabsturz wurden alle Passwörter zurückgesetzt.
              <br />
              Du wirst dann aufgefordert, ein neues Passwort zu vergeben.
              <br />
              <strong>Deine Daten (Hortzettel) sind sicher und wurden wiederhergestellt.</strong>
            </p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="text-white hover:bg-white/20 flex-shrink-0"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  );
}
