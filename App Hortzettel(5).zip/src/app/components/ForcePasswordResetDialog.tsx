import { useState } from "react";
import { AlertTriangle, Lock, Eye, EyeOff, CheckCircle2 } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "./ui/dialog";
import { toast } from "sonner";
import { api } from "../utils/api";
import { motion } from "motion/react";

interface ForcePasswordResetDialogProps {
  firstName: string;
  lastName: string;
  onPasswordSet: () => void;
}

export function ForcePasswordResetDialog({
  firstName,
  lastName,
  onPasswordSet,
}: ForcePasswordResetDialogProps) {
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSetPassword = async () => {
    if (!newPassword || newPassword.length < 4) {
      toast.error("Passwort muss mindestens 4 Zeichen lang sein");
      return;
    }

    if (newPassword !== confirmPassword) {
      toast.error("Passwörter stimmen nicht überein");
      return;
    }

    setLoading(true);
    try {
      // Update password in local storage
      const userKey = `local_user_${firstName.toLowerCase()}_${lastName.toLowerCase()}`;
      console.log(`[ForcePasswordReset] 🔐 Changing password for: ${firstName} ${lastName}`);
      console.log(`[ForcePasswordReset] UserKey: ${userKey}`);

      const userData = localStorage.getItem(userKey);

      if (!userData) {
        console.error(`[ForcePasswordReset] ❌ User not found: ${userKey}`);
        throw new Error("Benutzer nicht gefunden");
      }

      const user = JSON.parse(userData);
      console.log(`[ForcePasswordReset] Current password: ${user.password}`);

      user.password = newPassword;
      user.passwordResetRequired = false;
      user.lastPasswordChange = new Date().toISOString();

      localStorage.setItem(userKey, JSON.stringify(user));

      // Verify save
      const savedUser = JSON.parse(localStorage.getItem(userKey)!);
      console.log(`[ForcePasswordReset] ✅ Password saved: ${savedUser.password}`);
      console.log(`[ForcePasswordReset] LastPasswordChange: ${savedUser.lastPasswordChange}`);

      toast.success("✅ Passwort erfolgreich gesetzt!", {
        description: "Du kannst dich jetzt jederzeit mit deinem neuen Passwort anmelden."
      });

      // Dispatch event to update banner visibility AND admin dashboard
      console.log('[ForcePasswordReset] 📢 Dispatching passwordChanged event...');
      window.dispatchEvent(new CustomEvent('passwordChanged'));

      // Wait a bit before closing to ensure event is processed
      setTimeout(() => {
        console.log('[ForcePasswordReset] ✅ Event dispatched, closing dialog');
        onPasswordSet();
      }, 1500);
    } catch (error: any) {
      console.error("Error setting password:", error);
      toast.error("Fehler beim Setzen des Passworts", {
        description: error.message
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={true} onOpenChange={() => {
      // Dialog kann NICHT geschlossen werden - Benutzer MUSS Passwort ändern
      toast.error('Passwort-Änderung erforderlich', {
        description: 'Du musst ein neues Passwort vergeben, um fortzufahren.'
      });
    }}>
      <DialogContent
        className="sm:max-w-lg border-0 shadow-2xl overflow-hidden p-0"
        onInteractOutside={(e) => {
          e.preventDefault();
          toast.warning('Passwort muss geändert werden', {
            description: 'Dieser Schritt ist erforderlich, um fortzufahren.'
          });
        }}
        onEscapeKeyDown={(e) => {
          e.preventDefault();
          toast.warning('Passwort muss geändert werden', {
            description: 'Drücke ESC nicht - bitte ändere dein Passwort.'
          });
        }}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="relative"
        >
          {/* Warning Header */}
          <div className="relative bg-gradient-to-br from-amber-500/10 via-orange-500/10 to-red-500/10 p-8 pb-6">
            <div className="absolute inset-0 bg-grid-white/5" />
            <div className="relative">
              <div className="w-14 h-14 rounded-2xl bg-amber-500/20 backdrop-blur-xl border border-amber-500/30 flex items-center justify-center mb-4">
                <AlertTriangle className="h-7 w-7 text-amber-600 dark:text-amber-500" />
              </div>
              <DialogTitle className="text-2xl font-bold mb-2">
                ⚠️ Neues Passwort ERFORDERLICH
              </DialogTitle>
              <DialogDescription className="text-muted-foreground">
                Nach dem Serverabsturz musst du ein neues Passwort vergeben, bevor du fortfahren kannst.
              </DialogDescription>
              <div className="mt-3 bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800 rounded-lg p-3">
                <p className="text-sm text-red-900 dark:text-red-200 font-medium">
                  ⛔ Du kannst die App erst nach der Passwort-Änderung nutzen
                </p>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="p-8 pt-6 space-y-6">
            {/* Info Box */}
            <div className="bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-xl p-4">
              <div className="flex gap-3">
                <CheckCircle2 className="h-5 w-5 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="text-sm font-medium text-blue-900 dark:text-blue-200">
                    Willkommen zurück, {firstName}!
                  </p>
                  <p className="text-sm text-blue-800 dark:text-blue-300">
                    Alle deine Hortzettel und Daten sind sicher. Bitte vergib ein neues Passwort, um fortzufahren.
                  </p>
                </div>
              </div>
            </div>

            {/* Password Form */}
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="new-password" className="text-sm font-medium">
                  Neues Passwort
                </Label>
                <div className="relative group">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground transition-colors group-focus-within:text-primary" />
                  <Input
                    id="new-password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Mindestens 4 Zeichen"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="pl-10 pr-10 h-12 text-base"
                    autoFocus
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="confirm-password" className="text-sm font-medium">
                  Passwort bestätigen
                </Label>
                <div className="relative group">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground transition-colors group-focus-within:text-primary" />
                  <Input
                    id="confirm-password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Passwort wiederholen"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="pl-10 h-12 text-base"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && newPassword && confirmPassword) {
                        handleSetPassword();
                      }
                    }}
                  />
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <Button
              onClick={handleSetPassword}
              disabled={loading || !newPassword || !confirmPassword}
              className="w-full h-12 text-base"
            >
              {loading ? "Wird gespeichert..." : "Passwort speichern und fortfahren"}
            </Button>

            {/* Note */}
            <p className="text-xs text-center text-muted-foreground">
              Dieses Passwort wird sicher gespeichert und ist auch für den Administrator sichtbar.
            </p>
          </div>
        </motion.div>
      </DialogContent>
    </Dialog>
  );
}
