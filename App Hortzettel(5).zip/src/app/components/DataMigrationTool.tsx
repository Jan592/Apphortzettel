import { Card } from "./ui/card";
import { Database, CheckCircle2 } from "lucide-react";

export function DataMigrationTool() {
  return (
    <Card className="p-6">
      <div className="flex items-center gap-3 mb-4">
        <div className="p-2 bg-green-100 dark:bg-green-900 rounded-lg">
          <Database className="h-5 w-5 text-green-600 dark:text-green-300" />
        </div>
        <div>
          <h3 className="font-semibold">Daten-Migration</h3>
          <p className="text-sm text-muted-foreground">
            Datenmigration nicht mehr erforderlich
          </p>
        </div>
      </div>
      <div className="flex items-start gap-3 p-4 rounded-lg bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800">
        <CheckCircle2 className="h-5 w-5 text-green-600 dark:text-green-400 mt-0.5 shrink-0" />
        <div className="text-sm text-green-800 dark:text-green-200">
          <p className="font-medium mb-1">App läuft vollständig online</p>
          <p>Alle Daten werden direkt über das Supabase-Backend verwaltet. Eine lokale Migration ist nicht mehr notwendig.</p>
        </div>
      </div>
    </Card>
  );
}