import { useState } from "react";
import { AlertCircle, X, Info, Lock, User } from "lucide-react";
import { Button } from "./ui/button";
import { motion, AnimatePresence } from "motion/react";

export function QuickLoginHelp() {
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        className="mb-6"
      >
        <div className="bg-gradient-to-r from-blue-500/10 via-purple-500/10 to-pink-500/10 backdrop-blur-sm border-2 border-blue-300/30 dark:border-blue-500/30 rounded-2xl p-5 relative overflow-hidden">
          {/* Close button */}
          <button
            onClick={() => setIsVisible(false)}
            className="absolute top-3 right-3 text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="h-4 w-4" />
          </button>

          {/* Header */}
          <div className="flex items-start gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-blue-500/20 dark:bg-blue-500/30 backdrop-blur-sm flex items-center justify-center shrink-0">
              <Info className="h-5 w-5 text-blue-700 dark:text-blue-400" />
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-lg text-foreground mb-1">
                📢 Wichtig: So kannst du dich anmelden
              </h3>
              <p className="text-sm text-muted-foreground">
                Nach der Datenwiederherstellung hat sich dein Passwort geändert
              </p>
            </div>
          </div>

          {/* Instructions */}
          <div className="space-y-3 ml-13">
            <div className="bg-white/50 dark:bg-slate-800/50 backdrop-blur-sm rounded-xl p-4 space-y-3">
              <div className="flex items-start gap-3">
                <User className="h-5 w-5 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="font-semibold text-foreground mb-1">1. Dein Name</p>
                  <p className="text-sm text-muted-foreground">
                    Gib deinen <strong>vollständigen Namen</strong> ein (Vor- und Nachname)
                  </p>
                  <p className="text-xs text-muted-foreground mt-1 italic">
                    Beispiel: Jan Zörkler
                  </p>
                </div>
              </div>

              <div className="h-px bg-border" />

              <div className="flex items-start gap-3">
                <Lock className="h-5 w-5 text-green-600 dark:text-green-400 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="font-semibold text-foreground mb-1">2. Dein neues Passwort</p>
                  <p className="text-sm text-muted-foreground mb-2">
                    Verwende: <strong>VornameNachname</strong> (ohne Leerzeichen)
                  </p>
                  <div className="bg-green-50 dark:bg-green-950/30 border border-green-200 dark:border-green-800 rounded-lg p-3">
                    <p className="text-sm font-mono text-green-900 dark:text-green-300">
                      <span className="text-xs text-green-700 dark:text-green-400 block mb-1">Beispiele:</span>
                      • Jan Zörkler → <strong>JanZörkler</strong>
                      <br />
                      • Anna Müller → <strong>AnnaMüller</strong>
                      <br />
                      • Max Schmidt → <strong>MaxSchmidt</strong>
                    </p>
                  </div>
                  <p className="text-xs text-amber-700 dark:text-amber-400 mt-2 flex items-start gap-1.5">
                    <AlertCircle className="h-3.5 w-3.5 shrink-0 mt-0.5" />
                    <span>Groß-/Kleinschreibung beachten! Vorname mit großem Anfangsbuchstaben</span>
                  </p>
                </div>
              </div>
            </div>

            {/* Additional help */}
            <div className="bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800 rounded-lg p-3">
              <p className="text-sm text-amber-900 dark:text-amber-300">
                <strong>💡 Tipp:</strong> Nach dem Login kannst du dein Passwort im Profil ändern
              </p>
            </div>

            {/* Data restore reminder */}
            <div className="text-center pt-2">
              <p className="text-xs text-muted-foreground">
                Falls du dich immer noch nicht anmelden kannst, klicke auf
                <br />
                <strong>"Alle Daten wiederherstellen"</strong> weiter unten
              </p>
            </div>
          </div>
        </div>
      </motion.div>
    </AnimatePresence>
  );
}
