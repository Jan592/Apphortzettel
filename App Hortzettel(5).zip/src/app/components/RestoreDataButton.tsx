import { Button } from "./ui/button";
import { Database } from "lucide-react";
import { toast } from "sonner";

export function RestoreDataButton() {
  const handleRestore = () => {
    toast.info("Nicht erforderlich", {
      description: "Die App läuft vollständig online – alle Daten werden direkt aus dem Backend geladen."
    });
  };

  return (
    <Button
      onClick={handleRestore}
      variant="outline"
      className="w-full bg-blue-50 hover:bg-blue-100 dark:bg-blue-950 dark:hover:bg-blue-900 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800"
    >
      <Database className="h-4 w-4 mr-2" />
      Alle Daten wiederherstellen
    </Button>
  );
}