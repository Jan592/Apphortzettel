import { Info } from "lucide-react";
import { Card } from "./ui/card";

export function PasswordInfo() {
  return (
    <Card className="p-4 bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800">
      <div className="flex items-start gap-3">
        <Info className="h-5 w-5 text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" />
        <div className="text-sm">
          <p className="font-medium text-blue-900 dark:text-blue-100 mb-1">
            📝 Standard-Passwort-Regel
          </p>
          <p className="text-blue-800 dark:text-blue-200">
            Dein Passwort ist: <strong>VornameNachname</strong> (ohne Leerzeichen)
          </p>
          <div className="mt-2 space-y-1 text-blue-700 dark:text-blue-300">
            <p>Beispiele:</p>
            <ul className="list-disc list-inside ml-2 space-y-0.5">
              <li>Jan Zörkler → <code className="bg-blue-100 dark:bg-blue-900 px-1 rounded">JanZörkler</code></li>
              <li>Susann Kramer → <code className="bg-blue-100 dark:bg-blue-900 px-1 rounded">SusannKramer</code></li>
              <li>Michael Müller → <code className="bg-blue-100 dark:bg-blue-900 px-1 rounded">MichaelMüller</code></li>
            </ul>
          </div>
        </div>
      </div>
    </Card>
  );
}
