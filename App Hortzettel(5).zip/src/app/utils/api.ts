import { projectId, publicAnonKey } from './supabase/info';
import type {
  HortzettelData,
  ChildProfile,
  FamilyProfile,
  Announcement,
  HortzettelTemplate,
  AdminUser,
  AppSettings,
  SystemStats,
} from '../types/hortzettel';

const API_BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-fb86b8a8`;

// ─── Session-Keys (nur zur Sitzungsverwaltung, kein Datenspeicher) ────────────
const TOKEN_KEY = 'accessToken';
const USER_CACHE_KEY = 'server_user_cache';

export class ApiClient {
  private accessToken: string | null = null;

  // ─── Token ─────────────────────────────────────────────────────────────────

  setAccessToken(token: string | null) {
    this.accessToken = token;
    if (token) {
      localStorage.setItem(TOKEN_KEY, token);
    } else {
      localStorage.removeItem(TOKEN_KEY);
    }
  }

  getAccessToken(): string | null {
    if (!this.accessToken) {
      this.accessToken = localStorage.getItem(TOKEN_KEY);
    }
    return this.accessToken;
  }

  logout() {
    this.setAccessToken(null);
    localStorage.removeItem(USER_CACHE_KEY);
    localStorage.removeItem('current_user_key');
    localStorage.removeItem('hortzettel_user_session');
  }

  // ─── HTTP-Hilfsmethode ─────────────────────────────────────────────────────

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const token = this.getAccessToken();

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      // Authorization benutzt IMMER den publicAnonKey (Supabase JWT-Validierung),
      // der custom User-Token wird separat als X-Auth-Token mitgeschickt.
      'Authorization': `Bearer ${publicAnonKey}`,
      ...(token && !token.startsWith('local_') ? { 'X-Auth-Token': token } : {}),
      ...(options.headers as Record<string, string>),
    };

    const url = `${API_BASE_URL}${endpoint}`;
    console.log(`[API] ${options.method ?? 'GET'} ${url}`);

    const response = await fetch(url, { ...options, headers });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ error: `HTTP ${response.status}` }));
      const error: any = new Error(errorData.error ?? `Serverfehler ${response.status}`);
      error.status = response.status;
      // Bei 401: Session bereinigen damit kein Endlosloop entsteht
      if (response.status === 401) {
        console.warn('[API] 401 Unauthorized – Token ungültig, Session wird geleert');
        this.setAccessToken(null);
        localStorage.removeItem('server_user_cache');
      }
      throw error;
    }

    return response.json();
  }

  // ─── AUTH ───────────────────────────────────────────────────────────────────

  async signup(
    firstName: string,
    lastName: string,
    password: string,
    childProfile?: ChildProfile,
    familyProfile?: FamilyProfile,
  ) {
    return this.request<{ success: boolean; message: string }>('/signup', {
      method: 'POST',
      body: JSON.stringify({ firstName, lastName, password, childProfile, familyProfile }),
    });
  }

  async login(firstName: string, lastName: string, password: string) {
    const response = await this.request<{
      success: boolean;
      accessToken: string;
      user: {
        firstName: string;
        lastName: string;
        childProfile: any;
        familyProfile: any;
        role: string;
      };
    }>('/login', {
      method: 'POST',
      body: JSON.stringify({ firstName, lastName, password }),
    });

    this.setAccessToken(response.accessToken);
    localStorage.setItem(USER_CACHE_KEY, JSON.stringify(response.user));
    console.log('[API] ✅ Login erfolgreich:', response.user.firstName, response.user.lastName);
    return response;
  }

  async getUser() {
    const cached = localStorage.getItem(USER_CACHE_KEY);
    if (cached) {
      return JSON.parse(cached) as {
        firstName: string;
        lastName: string;
        childProfile: any;
        familyProfile: any;
        role: string;
      };
    }
    throw new Error('Keine aktive Sitzung. Bitte erneut anmelden.');
  }

  async updateProfile(
    firstName: string,
    lastName: string,
    childProfile: ChildProfile,
    familyProfile: FamilyProfile,
    password?: string,
  ) {
    const result = await this.request<{ success: boolean; message: string }>('/user/profile', {
      method: 'PUT',
      body: JSON.stringify({ firstName, lastName, childProfile, familyProfile, password }),
    });
    // Cache aktualisieren
    const cached = localStorage.getItem(USER_CACHE_KEY);
    if (cached) {
      const user = JSON.parse(cached);
      localStorage.setItem(USER_CACHE_KEY, JSON.stringify({ ...user, firstName, lastName, childProfile, familyProfile }));
    }
    return result;
  }

  async requestPasswordReset(firstName: string, lastName: string) {
    return this.request<{ success: boolean; temporaryPassword: string; message: string }>(
      '/reset-password',
      { method: 'POST', body: JSON.stringify({ firstName, lastName }) },
    );
  }

  // ─── HORTZETTEL ─────────────────────────────────────────────────────────────

  async getHortzettel() {
    return this.request<{ hortzettel: (HortzettelData & { id: string; createdAt: string })[] }>(
      '/hortzettel',
    );
  }

  async createHortzettel(data: HortzettelData) {
    return this.request<{ success: boolean; hortzettel: HortzettelData & { id: string; createdAt: string } }>(
      '/hortzettel',
      { method: 'POST', body: JSON.stringify(data) },
    );
  }

  async updateHortzettel(id: string, data: HortzettelData) {
    return this.request<{ success: boolean; hortzettel: HortzettelData & { id: string } }>(
      `/hortzettel/${encodeURIComponent(id)}`,
      { method: 'PUT', body: JSON.stringify(data) },
    );
  }

  async deleteHortzettel(id: string) {
    return this.request<{ success: boolean; message: string }>(
      `/hortzettel/${encodeURIComponent(id)}`,
      { method: 'DELETE' },
    );
  }

  async autoArchiveOldHortzettel() {
    return this.request<{ success: boolean; archivedCount: number; message: string }>(
      '/hortzettel/auto-archive',
      { method: 'POST' },
    );
  }

  // ─── HORTNER ────────────────────────────────────────────────────────────────

  async hortnerLogin(klasse: string, password: string) {
    return this.request<{ success: boolean; klasse: string }>('/hortner/login', {
      method: 'POST',
      body: JSON.stringify({ klasse, password }),
    });
  }

  async getHortnerHortzettel() {
    return this.request<{ hortzettel: (HortzettelData & { id: string; createdAt: string })[] }>(
      '/hortner/hortzettel',
    );
  }

  async archiveCurrentWeek() {
    return this.request<{ success: boolean; archivedCount: number; message: string }>(
      '/hortner/archive-week',
      { method: 'POST' },
    );
  }

  // ─── ANNOUNCEMENTS ──────────────────────────────────────────────────────────

  async getAnnouncements() {
    return this.request<{ announcements: Announcement[] }>('/announcements');
  }

  async createAnnouncement(
    title: string,
    message: string,
    type: 'info' | 'warning' | 'urgent',
    createdBy?: string,
  ) {
    return this.request<{ success: boolean; announcement: Announcement }>('/announcements', {
      method: 'POST',
      body: JSON.stringify({ title, message, type, createdBy }),
    });
  }

  async deleteAnnouncement(id: string) {
    return this.request<{ success: boolean; message: string }>(
      `/announcements/${encodeURIComponent(id)}`,
      { method: 'DELETE' },
    );
  }

  // ─── TEMPLATES ──────────────────────────────────────────────────────────────

  async getTemplates() {
    return this.request<{ templates: HortzettelTemplate[] }>('/templates');
  }

  async createTemplate(name: string, data: Partial<HortzettelData>) {
    return this.request<{ success: boolean; template: HortzettelTemplate }>('/templates', {
      method: 'POST',
      body: JSON.stringify({ name, data }),
    });
  }

  async updateTemplate(id: string, name: string) {
    return this.request<{ success: boolean; template: HortzettelTemplate }>(
      `/templates/${encodeURIComponent(id)}`,
      { method: 'PUT', body: JSON.stringify({ name }) },
    );
  }

  async deleteTemplate(id: string) {
    return this.request<{ success: boolean; message: string }>(
      `/templates/${encodeURIComponent(id)}`,
      { method: 'DELETE' },
    );
  }

  // ─── ADMIN ──────────────────────────────────────────────────────────────────

  async adminLogin(email: string, password: string) {
    const response = await this.request<{
      success: boolean;
      accessToken: string;
      admin: { email: string };
    }>('/admin/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    if (response.accessToken) this.setAccessToken(response.accessToken);
    return response;
  }

  async getAdminStats() {
    return this.request<{ stats: SystemStats }>('/admin/stats');
  }

  async getAllUsers() {
    return this.request<{ users: AdminUser[] }>('/admin/users');
  }

  async updateUserProfile(userId: string, data: Partial<AdminUser>) {
    return this.request<{ success: boolean; user: AdminUser }>(`/admin/users/${encodeURIComponent(userId)}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  }

  async deleteUser(userId: string) {
    return this.request<{ success: boolean; message: string }>(
      `/admin/users/${encodeURIComponent(userId)}`,
      { method: 'DELETE' },
    );
  }

  async resetUserPassword(userId: string, newPassword: string) {
    return this.request<{ success: boolean; message: string }>('/admin/reset-password', {
      method: 'POST',
      body: JSON.stringify({ userId, newPassword }),
    });
  }

  async createUser(firstName: string, lastName: string, password: string) {
    return this.request<{ success: boolean; message: string; user: AdminUser }>('/admin/users', {
      method: 'POST',
      body: JSON.stringify({ firstName, lastName, password }),
    });
  }

  async updateUserRole(userId: string, role: 'parent' | 'hortner' | 'admin') {
    return this.request<{ success: boolean; message: string }>(
      `/admin/users/${encodeURIComponent(userId)}/role`,
      { method: 'PUT', body: JSON.stringify({ role }) },
    );
  }

  // ─── SETTINGS ───────────────────────────────────────────────────────────────

  async getSettings() {
    try {
      const response = await fetch(`${API_BASE_URL}/admin/settings`, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
        },
      });
      if (!response.ok) return { settings: null };
      return response.json();
    } catch {
      return { settings: null };
    }
  }

  async getAppSettings() {
    return this.request<{ settings: AppSettings }>('/admin/settings');
  }

  async updateAppSettings(settings: Partial<AppSettings>) {
    return this.request<{ success: boolean; settings: AppSettings }>('/admin/settings', {
      method: 'PUT',
      body: JSON.stringify(settings),
    });
  }

  async updateSettings(settings: Partial<AppSettings>) {
    return this.updateAppSettings(settings);
  }

  async getTimeRestrictions() {
    return this.request<{ settings: any }>('/admin/time-restrictions');
  }

  async updateTimeRestrictions(settings: any) {
    return this.request<{ success: boolean }>('/admin/time-restrictions', {
      method: 'PUT',
      body: JSON.stringify(settings),
    });
  }

  // ─── LOGO ──────────────────────────────────────────────────────────────────

  async getLogo() {
    return this.request<{ logo: string | null }>('/logo');
  }

  // ─── MESSAGES ───────────────────────────────────────────────────────────────

  async getMessages() {
    return this.request<{ messages: any[] }>('/messages');
  }

  async getHortnerMessages(klasse: string) {
    return this.request<{ messages: any[] }>(`/hortner/messages/${encodeURIComponent(klasse)}`);
  }

  async sendMessage(data: { subject: string; message: string; klasse?: string }) {
    return this.request<{ success: boolean; message: any }>('/messages', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async markMessageRead(messageId: string) {
    return this.request<{ success: boolean }>(`/messages/${encodeURIComponent(messageId)}/read`, {
      method: 'PUT',
    });
  }
}

export const api = new ApiClient();