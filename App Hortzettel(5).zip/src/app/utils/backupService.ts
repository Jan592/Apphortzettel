// Backup Service - collects all localStorage data and creates a structured JSON backup

export interface BackupData {
  version: string;
  createdAt: string;
  appName: string;
  stats: {
    userCount: number;
    hortzettelCount: number;
    settingsCount: number;
  };
  users: Record<string, unknown>[];
  hortzettel: Record<string, unknown>[];
  settings: Record<string, unknown>;
  rawKeys: string[];
}

export interface BackupRecord {
  id: string;
  createdAt: string;
  type: 'auto' | 'manual';
  size: number;
  driveFileId?: string;
  driveFileName?: string;
  status: 'success' | 'failed' | 'pending';
}

const BACKUP_HISTORY_KEY = 'backup_history';
const LAST_AUTO_BACKUP_KEY = 'last_auto_backup_date';
const BACKUP_SCHEDULE_KEY = 'backup_schedule_enabled';

export function collectBackupData(): BackupData {
  const users: Record<string, unknown>[] = [];
  const hortzettel: Record<string, unknown>[] = [];
  const settings: Record<string, unknown> = {};
  const rawKeys: string[] = [];

  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (!key) continue;
    rawKeys.push(key);

    try {
      const raw = localStorage.getItem(key) ?? '';
      let value: unknown;
      try {
        value = JSON.parse(raw);
      } catch {
        value = raw;
      }

      if (key.startsWith('local_user_')) {
        users.push({ _key: key, ...(typeof value === 'object' && value !== null ? value as object : { value }) });
      } else if (key.startsWith('hortzettel_') || key.startsWith('hz_')) {
        hortzettel.push({ _key: key, ...(typeof value === 'object' && value !== null ? value as object : { value }) });
      } else if (
        key.startsWith('appSettings') ||
        key.startsWith('settings_') ||
        key === 'schoolName' ||
        key === 'appConfig' ||
        key.startsWith('design_') ||
        key.startsWith('pwa_')
      ) {
        settings[key] = value;
      }
    } catch (e) {
      console.warn(`[BackupService] Could not read key: ${key}`, e);
    }
  }

  const backup: BackupData = {
    version: '1.0',
    createdAt: new Date().toISOString(),
    appName: 'Hortzettel App',
    stats: {
      userCount: users.length,
      hortzettelCount: hortzettel.length,
      settingsCount: Object.keys(settings).length,
    },
    users,
    hortzettel,
    settings,
    rawKeys,
  };

  console.log(`[BackupService] Backup collected: ${users.length} users, ${hortzettel.length} Hortzettel`);
  return backup;
}

export function createBackupBlob(data: BackupData): Blob {
  const json = JSON.stringify(data, null, 2);
  return new Blob([json], { type: 'application/json' });
}

export function generateBackupFileName(): string {
  const now = new Date();
  const date = now.toISOString().split('T')[0];
  const time = now.toTimeString().split(' ')[0].replace(/:/g, '-');
  return `hortzettel_backup_${date}_${time}.json`;
}

export function downloadBackupLocally(data: BackupData): void {
  const blob = createBackupBlob(data);
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = generateBackupFileName();
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function getBackupHistory(): BackupRecord[] {
  try {
    const raw = localStorage.getItem(BACKUP_HISTORY_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function addBackupRecord(record: BackupRecord): void {
  const history = getBackupHistory();
  history.unshift(record);
  // Keep last 20 records
  const trimmed = history.slice(0, 20);
  localStorage.setItem(BACKUP_HISTORY_KEY, JSON.stringify(trimmed));
}

export function updateBackupRecord(id: string, updates: Partial<BackupRecord>): void {
  const history = getBackupHistory();
  const idx = history.findIndex((r) => r.id === id);
  if (idx !== -1) {
    history[idx] = { ...history[idx], ...updates };
    localStorage.setItem(BACKUP_HISTORY_KEY, JSON.stringify(history));
  }
}

export function getLastAutoBackupDate(): string | null {
  return localStorage.getItem(LAST_AUTO_BACKUP_KEY);
}

export function setLastAutoBackupDate(date: string): void {
  localStorage.setItem(LAST_AUTO_BACKUP_KEY, date);
}

export function isAutoBackupEnabled(): boolean {
  const v = localStorage.getItem(BACKUP_SCHEDULE_KEY);
  return v === null ? true : v === 'true';
}

export function setAutoBackupEnabled(enabled: boolean): void {
  localStorage.setItem(BACKUP_SCHEDULE_KEY, String(enabled));
}

export function shouldRunAutoBackup(): boolean {
  if (!isAutoBackupEnabled()) return false;
  const lastDate = getLastAutoBackupDate();
  if (!lastDate) return true;
  const today = new Date().toISOString().split('T')[0];
  return lastDate !== today;
}

/** Returns milliseconds until next 2:00 AM */
export function msUntilNext2AM(): number {
  const now = new Date();
  const next2am = new Date(now);
  next2am.setHours(2, 0, 0, 0);
  if (next2am <= now) {
    next2am.setDate(next2am.getDate() + 1);
  }
  return next2am.getTime() - now.getTime();
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

export function formatDate(iso: string): string {
  try {
    return new Intl.DateTimeFormat('de-DE', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(new Date(iso));
  } catch {
    return iso;
  }
}
