// Google Drive Service - via Google Apps Script + Supabase-Proxy
// Kein OAuth / kein Client-ID nötig.
// Der Supabase-Server leitet die Anfrage serverseitig weiter (kein CORS-Problem).

import { projectId, publicAnonKey } from '/utils/supabase/info';

const SCRIPT_URL_KEY     = 'gdrive_script_url';
const SCRIPT_FOLDER_KEY  = 'gdrive_script_folder';
const UPLOADED_FILES_KEY = 'gdrive_uploaded_files';
const DEFAULT_FOLDER     = 'Hortzettel Backups';

const PROXY_URL = `https://${projectId}.supabase.co/functions/v1/make-server-fb86b8a8/proxy-backup`;

// ─── Apps Script Code (einmalig deployen) ────────────────────────────────────
export const APPS_SCRIPT_CODE = `// =========================================
//  Hortzettel Backup - Google Apps Script
//  Einmalig als Web App deployen (s. Anleitung)
// =========================================

function doPost(e) {
  try {
    var fileName, content, folder;

    // JSON-Body (vom Supabase-Proxy gesendet)
    if (e.postData && e.postData.contents) {
      try {
        var data = JSON.parse(e.postData.contents);
        fileName = data.fileName;
        content  = data.content;
        folder   = data.folder;
      } catch (_) {
        // Fallback: Form-Parameter
        fileName = e.parameter.fileName;
        content  = e.parameter.content;
        folder   = e.parameter.folder;
      }
    } else {
      fileName = e.parameter.fileName;
      content  = e.parameter.content;
      folder   = e.parameter.folder;
    }

    fileName = fileName
      || ('backup_' + new Date().toISOString().replace(/[:.]/g,'-') + '.json');
    folder   = folder || 'Hortzettel Backups';

    var f = getOrCreateFolder_(folder);
    f.createFile(fileName, content || '{}', 'application/json');

    return json_({ ok: true, fileName: fileName });
  } catch(err) {
    return json_({ ok: false, error: err.toString() });
  }
}

function doGet(e) {
  return json_({ ok: true, status: 'Hortzettel Backup Script aktiv' });
}

function getOrCreateFolder_(name) {
  var iter = DriveApp.getFoldersByName(name);
  return iter.hasNext() ? iter.next() : DriveApp.createFolder(name);
}
function json_(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}`;

// ─── Config ──────────────────────────────────────────────────────────────────

export function getScriptUrl(): string {
  return localStorage.getItem(SCRIPT_URL_KEY) ?? '';
}

export function setScriptUrl(url: string): void {
  localStorage.setItem(SCRIPT_URL_KEY, url.trim());
}

export function clearScriptUrl(): void {
  localStorage.removeItem(SCRIPT_URL_KEY);
}

export function isConfigured(): boolean {
  return !!getScriptUrl();
}

export function getScriptFolder(): string {
  return localStorage.getItem(SCRIPT_FOLDER_KEY) || DEFAULT_FOLDER;
}

export function setScriptFolder(name: string): void {
  localStorage.setItem(SCRIPT_FOLDER_KEY, name.trim() || DEFAULT_FOLDER);
}

/** Google Drive-Suche nach dem Ordner (direkter Link) */
export function getDriveFolderSearchUrl(): string {
  const folder = getScriptFolder();
  return `https://drive.google.com/drive/search?q=${encodeURIComponent(folder)}`;
}

// ─── Lokales Upload-Tracking ─────────────────────────────────────────────────

export interface UploadedFile {
  id: string;
  name: string;
  uploadedAt: string;
  size: number;
}

export function getUploadedFiles(): UploadedFile[] {
  try {
    return JSON.parse(localStorage.getItem(UPLOADED_FILES_KEY) ?? '[]');
  } catch {
    return [];
  }
}

export function addUploadedFile(file: Omit<UploadedFile, 'id'>): void {
  const files = getUploadedFiles();
  files.unshift({ ...file, id: Date.now().toString() });
  localStorage.setItem(UPLOADED_FILES_KEY, JSON.stringify(files.slice(0, 50)));
}

export function removeUploadedFile(id: string): void {
  const files = getUploadedFiles().filter(f => f.id !== id);
  localStorage.setItem(UPLOADED_FILES_KEY, JSON.stringify(files));
}

export function clearUploadedFiles(): void {
  localStorage.removeItem(UPLOADED_FILES_KEY);
}

// ─── Proxy-Aufruf (intern) ───────────────────────────────────────────────────

async function callProxy(body: Record<string, unknown>): Promise<{ ok: boolean; error?: string; [key: string]: unknown }> {
  const res = await fetch(PROXY_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${publicAnonKey}`,
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Proxy-Fehler (${res.status}): ${text.slice(0, 300)}`);
  }

  return res.json() as Promise<{ ok: boolean; error?: string }>;
}

// ─── Upload via Supabase-Proxy → Apps Script ──────────────────────────────────

export async function uploadViaAppScript(jsonContent: string, fileName: string): Promise<void> {
  const scriptUrl = getScriptUrl();
  if (!scriptUrl) throw new Error('Kein Script-URL konfiguriert');

  const result = await callProxy({
    scriptUrl,
    fileName,
    content: jsonContent,
    folder: getScriptFolder(),
  });

  if (!result.ok) {
    throw new Error(result.error ?? 'Upload fehlgeschlagen');
  }

  // Lokal tracken
  addUploadedFile({
    name: fileName,
    uploadedAt: new Date().toISOString(),
    size: new Blob([jsonContent]).size,
  });
}

// ─── Verbindungstest ─────────────────────────────────────────────────────────

export async function testScriptConnection(): Promise<boolean> {
  const scriptUrl = getScriptUrl();
  if (!scriptUrl) return false;
  try {
    const result = await callProxy({ scriptUrl, testOnly: true });
    return result.ok === true;
  } catch {
    return false;
  }
}
