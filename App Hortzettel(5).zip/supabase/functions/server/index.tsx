import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization", "X-Auth-Token"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Helper function to generate simple tokens
function generateToken(userId: string): string {
  return `token_${userId}_${Date.now()}`;
}

// Helper function to hash passwords (simplified)
function hashPassword(password: string): string {
  // In production, use proper hashing like bcrypt
  return `hashed_${password}`;
}

// Helper function to verify auth token
async function verifyAuth(c: any): Promise<string | null> {
  // Custom user token kommt im X-Auth-Token Header (Authorization = Supabase publicAnonKey)
  const token = c.req.header('X-Auth-Token') || c.req.header('Authorization')?.substring(7);
  if (!token) return null;

  // Supabase publicAnonKey oder leerer Token → nicht authentifiziert
  if (!token || token.length < 20 || !token.startsWith('token_')) return null;

  // Find user by token
  const users = await kv.getByPrefix("user:");
  for (const user of users) {
    if (user.accessToken === token) {
      return user.id;
    }
  }
  return null;
}

// ========== HEALTH & SETTINGS ==========

app.get("/make-server-fb86b8a8/health", (c) => {
  return c.json({ status: "ok" });
});

app.get("/make-server-fb86b8a8/admin/settings", async (c) => {
  try {
    const settings = await kv.get("app_settings");
    return c.json({
      settings: settings || {
        schoolName: "Grundschule Auma",
        content: {
          appTitle: "Hortzettel App",
          loginTitle: "Anmelden",
          registerTitle: "Registrieren",
        },
        classes: ["1", "2", "3", "4"],
      }
    });
  } catch (error) {
    console.log("Error loading settings:", error);
    return c.json({
      settings: {
        schoolName: "Grundschule Auma",
        content: {
          appTitle: "Hortzettel App",
          loginTitle: "Anmelden",
          registerTitle: "Registrieren",
        },
        classes: ["1", "2", "3", "4"],
      }
    });
  }
});

app.put("/make-server-fb86b8a8/admin/settings", async (c) => {
  try {
    const body = await c.req.json();
    await kv.set("app_settings", body);
    return c.json({ success: true, settings: body });
  } catch (error) {
    console.log("Error updating settings:", error);
    return c.json({ error: "Failed to update settings" }, 500);
  }
});

// ========== USER ENDPOINTS ==========

app.post("/make-server-fb86b8a8/signup", async (c) => {
  try {
    const { firstName, lastName, password, childProfile, familyProfile } = await c.req.json();

    const userId = `user:${firstName.toLowerCase()}_${lastName.toLowerCase()}`;
    const existingUser = await kv.get(userId);

    if (existingUser) {
      return c.json({ error: "Benutzer existiert bereits" }, 409);
    }

    const user = {
      id: userId,
      firstName,
      lastName,
      password: hashPassword(password),
      childProfile: childProfile || {},
      familyProfile: familyProfile || {},
      role: 'parent',
      createdAt: new Date().toISOString(),
    };

    await kv.set(userId, user);

    return c.json({ success: true, message: "Registrierung erfolgreich" });
  } catch (error) {
    console.error("Signup error:", error);
    return c.json({ error: "Registrierung fehlgeschlagen" }, 500);
  }
});

app.post("/make-server-fb86b8a8/login", async (c) => {
  try {
    const { firstName, lastName, password } = await c.req.json();

    const userId = `user:${firstName.toLowerCase()}_${lastName.toLowerCase()}`;
    const user = await kv.get(userId);

    if (!user || user.password !== hashPassword(password)) {
      return c.json({ error: "Ungültige Anmeldedaten" }, 401);
    }

    const accessToken = generateToken(userId);
    user.accessToken = accessToken;
    await kv.set(userId, user);

    return c.json({
      success: true,
      accessToken,
      user: {
        firstName: user.firstName,
        lastName: user.lastName,
        childProfile: user.childProfile,
        familyProfile: user.familyProfile,
        role: user.role || 'parent',
      }
    });
  } catch (error) {
    console.error("Login error:", error);
    return c.json({ error: "Anmeldung fehlgeschlagen" }, 500);
  }
});

app.get("/make-server-fb86b8a8/user", async (c) => {
  try {
    const userId = await verifyAuth(c);
    if (!userId) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const user = await kv.get(userId);
    if (!user) {
      return c.json({ error: "User not found" }, 404);
    }

    return c.json({
      firstName: user.firstName,
      lastName: user.lastName,
      childProfile: user.childProfile,
      familyProfile: user.familyProfile,
      role: user.role || 'parent',
    });
  } catch (error) {
    console.error("Get user error:", error);
    return c.json({ error: "Fehler beim Laden des Benutzers" }, 500);
  }
});

app.put("/make-server-fb86b8a8/user/profile", async (c) => {
  try {
    const userId = await verifyAuth(c);
    if (!userId) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const user = await kv.get(userId);
    if (!user) {
      return c.json({ error: "User not found" }, 404);
    }

    const { firstName, lastName, childProfile, familyProfile, password } = await c.req.json();

    user.firstName = firstName;
    user.lastName = lastName;
    user.childProfile = childProfile;
    user.familyProfile = familyProfile;
    if (password) {
      user.password = hashPassword(password);
    }

    await kv.set(userId, user);

    return c.json({ success: true, message: "Profil aktualisiert" });
  } catch (error) {
    console.error("Update profile error:", error);
    return c.json({ error: "Fehler beim Aktualisieren" }, 500);
  }
});

// ========== HORTZETTEL ENDPOINTS ==========

app.get("/make-server-fb86b8a8/hortzettel", async (c) => {
  try {
    const userId = await verifyAuth(c);
    if (!userId) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const allHortzettel = await kv.getByPrefix(`hortzettel:${userId}:`);

    return c.json({ hortzettel: allHortzettel || [] });
  } catch (error) {
    console.error("Get hortzettel error:", error);
    return c.json({ error: "Fehler beim Laden" }, 500);
  }
});

app.post("/make-server-fb86b8a8/hortzettel", async (c) => {
  try {
    const userId = await verifyAuth(c);
    if (!userId) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const data = await c.req.json();
    const hortzettelId = `hortzettel:${userId}:${Date.now()}`;

    const hortzettel = {
      ...data,
      id: hortzettelId,
      userId,
      createdAt: new Date().toISOString(),
    };

    await kv.set(hortzettelId, hortzettel);

    return c.json({ success: true, hortzettel });
  } catch (error) {
    console.error("Create hortzettel error:", error);
    return c.json({ error: "Fehler beim Erstellen" }, 500);
  }
});

app.put("/make-server-fb86b8a8/hortzettel/:id", async (c) => {
  try {
    const userId = await verifyAuth(c);
    if (!userId) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const id = c.req.param('id');
    const existingHortzettel = await kv.get(id);

    if (!existingHortzettel || existingHortzettel.userId !== userId) {
      return c.json({ error: "Not found" }, 404);
    }

    const data = await c.req.json();
    const hortzettel = {
      ...existingHortzettel,
      ...data,
      id,
      userId,
    };

    await kv.set(id, hortzettel);

    return c.json({ success: true, hortzettel });
  } catch (error) {
    console.error("Update hortzettel error:", error);
    return c.json({ error: "Fehler beim Aktualisieren" }, 500);
  }
});

app.delete("/make-server-fb86b8a8/hortzettel/:id", async (c) => {
  try {
    const userId = await verifyAuth(c);
    if (!userId) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const id = c.req.param('id');
    const hortzettel = await kv.get(id);

    if (!hortzettel || hortzettel.userId !== userId) {
      return c.json({ error: "Not found" }, 404);
    }

    await kv.del(id);

    return c.json({ success: true, message: "Gelöscht" });
  } catch (error) {
    console.error("Delete hortzettel error:", error);
    return c.json({ error: "Fehler beim Löschen" }, 500);
  }
});

// ========== PASSWORD RESET ==========

app.post("/make-server-fb86b8a8/reset-password", async (c) => {
  try {
    const { firstName, lastName } = await c.req.json();

    if (!firstName || !lastName) {
      return c.json({ error: "Vor- und Nachname sind erforderlich" }, 400);
    }

    const userId = `user:${firstName.toLowerCase()}_${lastName.toLowerCase()}`;
    const user = await kv.get(userId);

    if (!user) {
      return c.json({ error: "Benutzer nicht gefunden. Bitte überprüfe den Namen." }, 404);
    }

    // Generate a random temporary password (8 chars alphanumeric)
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789";
    let temporaryPassword = "";
    for (let i = 0; i < 8; i++) {
      temporaryPassword += chars.charAt(Math.floor(Math.random() * chars.length));
    }

    user.password = hashPassword(temporaryPassword);
    user.forcePasswordReset = true;
    await kv.set(userId, user);

    console.log(`[reset-password] Temporary password set for ${firstName} ${lastName}`);

    return c.json({
      success: true,
      temporaryPassword,
      message: "Temporäres Passwort wurde erstellt. Bitte nach dem Login das Passwort ändern."
    });
  } catch (error) {
    console.error("Password reset error:", error);
    return c.json({ error: `Fehler beim Zurücksetzen des Passworts: ${error}` }, 500);
  }
});

// ========== ADMIN ENDPOINTS ==========

app.post("/make-server-fb86b8a8/admin/login", async (c) => {
  try {
    const { email, password } = await c.req.json();

    // Simple admin check - in production use proper auth
    const adminId = "admin:main";
    let admin = await kv.get(adminId);

    // Create default admin if doesn't exist
    if (!admin) {
      admin = {
        id: adminId,
        email: "admin@hortzettel.de",
        password: hashPassword("Admin2024!"),
      };
      await kv.set(adminId, admin);
    }

    if (email !== admin.email || hashPassword(password) !== admin.password) {
      return c.json({ error: "Ungültige Anmeldedaten" }, 401);
    }

    const accessToken = generateToken(adminId);
    admin.accessToken = accessToken;
    await kv.set(adminId, admin);

    return c.json({
      success: true,
      accessToken,
      admin: { email: admin.email }
    });
  } catch (error) {
    console.error("Admin login error:", error);
    return c.json({ error: "Anmeldung fehlgeschlagen" }, 500);
  }
});

app.get("/make-server-fb86b8a8/admin/stats", async (c) => {
  try {
    const allUsers = await kv.getByPrefix("user:");
    const allHortzettel = await kv.getByPrefix("hortzettel:");

    return c.json({
      stats: {
        totalUsers: allUsers.length,
        totalHortzettel: allHortzettel.length,
        activeToday: 0,
      }
    });
  } catch (error) {
    console.error("Stats error:", error);
    return c.json({ error: "Fehler beim Laden der Statistiken" }, 500);
  }
});

app.get("/make-server-fb86b8a8/admin/users", async (c) => {
  try {
    const users = await kv.getByPrefix("user:");

    const userList = users.map(u => ({
      id: u.id,
      firstName: u.firstName,
      lastName: u.lastName,
      role: u.role || 'parent',
      createdAt: u.createdAt,
    }));

    return c.json({ users: userList });
  } catch (error) {
    console.error("Get users error:", error);
    return c.json({ error: "Fehler beim Laden der Benutzer" }, 500);
  }
});

// ========== ANNOUNCEMENTS ==========

app.get("/make-server-fb86b8a8/announcements", async (c) => {
  try {
    const announcements = await kv.getByPrefix("announcement:");
    return c.json({ announcements: announcements || [] });
  } catch (error) {
    console.error("Get announcements error:", error);
    return c.json({ announcements: [] });
  }
});

app.post("/make-server-fb86b8a8/announcements", async (c) => {
  try {
    const { title, message, type, createdBy } = await c.req.json();

    const announcementId = `announcement:${Date.now()}`;
    const announcement = {
      id: announcementId,
      title,
      message,
      type,
      createdBy: createdBy || 'Admin',
      createdAt: new Date().toISOString(),
    };

    await kv.set(announcementId, announcement);

    return c.json({ success: true, announcement });
  } catch (error) {
    console.error("Create announcement error:", error);
    return c.json({ error: "Fehler beim Erstellen" }, 500);
  }
});

app.delete("/make-server-fb86b8a8/announcements/:id", async (c) => {
  try {
    const id = c.req.param('id');
    await kv.del(id);
    return c.json({ success: true, message: "Gelöscht" });
  } catch (error) {
    console.error("Delete announcement error:", error);
    return c.json({ error: "Fehler beim Löschen" }, 500);
  }
});

// ─── Google Apps Script Backup-Proxy ─────────────────────────────────────────
// Leitet Backup-Daten serverseitig an ein Apps Script weiter.
// Umgeht Browser-CORS und no-cors Body-Verlust.
app.post("/make-server-fb86b8a8/proxy-backup", async (c) => {
  try {
    const body = await c.req.json() as {
      scriptUrl: string;
      fileName: string;
      content: string;
      folder?: string;
      testOnly?: boolean;
    };

    const { scriptUrl, fileName, content, folder, testOnly } = body;

    if (!scriptUrl) {
      return c.json({ ok: false, error: "scriptUrl fehlt" }, 400);
    }

    // Verbindungstest-Modus: nur prüfen ob Script erreichbar ist
    if (testOnly) {
      try {
        const probe = await fetch(scriptUrl, { method: "GET", redirect: "follow" });
        return c.json({ ok: true, reachable: probe.ok || probe.type === "opaqueredirect", status: probe.status });
      } catch (e) {
        return c.json({ ok: false, reachable: false, error: String(e) });
      }
    }

    if (!content || !fileName) {
      return c.json({ ok: false, error: "fileName und content sind erforderlich" }, 400);
    }

    // Schritt 1: Redirect-URL des Apps Scripts ermitteln (Apps Script macht 302)
    let targetUrl = scriptUrl;
    try {
      const probe = await fetch(scriptUrl, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "probe=1",
        redirect: "manual",
      });
      const loc = probe.headers.get("location");
      if (loc) {
        targetUrl = loc;
        console.log("[proxy-backup] Redirect zu:", targetUrl.slice(0, 100));
      }
    } catch (probeErr) {
      console.log("[proxy-backup] Probe fehlgeschlagen, Original-URL wird verwendet:", probeErr);
    }

    // Schritt 2: JSON direkt an die Ziel-URL senden (POST bleibt POST)
    const payload = JSON.stringify({
      fileName,
      content,
      folder: folder || "Hortzettel Backups",
    });

    const response = await fetch(targetUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: payload,
      redirect: "follow",
    });

    const responseText = await response.text();
    console.log("[proxy-backup] Apps Script Status:", response.status, responseText.slice(0, 200));

    return c.json({ ok: true, status: response.status, message: responseText.slice(0, 500) });
  } catch (err) {
    console.error("[proxy-backup] Fehler:", err);
    return c.json({ ok: false, error: String(err) }, 500);
  }
});

// ========== LOGO ENDPOINT ==========

app.get("/make-server-fb86b8a8/logo", async (c) => {
  try {
    const settings = await kv.get("app_settings");
    const logo = settings?.logo || null;
    return c.json({ logo });
  } catch (error) {
    console.log("Error loading logo:", error);
    return c.json({ logo: null });
  }
});

app.put("/make-server-fb86b8a8/logo", async (c) => {
  try {
    const { logo } = await c.req.json();
    const settings = await kv.get("app_settings") || {};
    settings.logo = logo;
    await kv.set("app_settings", settings);
    return c.json({ success: true });
  } catch (error) {
    console.log("Error saving logo:", error);
    return c.json({ error: "Fehler beim Speichern" }, 500);
  }
});

// ========== MESSAGES ENDPOINTS ==========

app.get("/make-server-fb86b8a8/messages", async (c) => {
  try {
    const userId = await verifyAuth(c);
    if (!userId) return c.json({ error: "Unauthorized" }, 401);

    const messages = await kv.getByPrefix(`message:${userId}:`);
    return c.json({ messages: messages || [] });
  } catch (error) {
    console.log("Error loading messages:", error);
    return c.json({ messages: [] });
  }
});

app.post("/make-server-fb86b8a8/messages", async (c) => {
  try {
    const userId = await verifyAuth(c);
    if (!userId) return c.json({ error: "Unauthorized" }, 401);

    const { subject, message, klasse } = await c.req.json();
    const msgId = `message:${userId}:${Date.now()}`;
    const msg = { id: msgId, subject, message, klasse, userId, createdAt: new Date().toISOString(), read: false };
    await kv.set(msgId, msg);
    return c.json({ success: true, message: msg });
  } catch (error) {
    console.log("Error sending message:", error);
    return c.json({ error: "Fehler beim Senden" }, 500);
  }
});

app.put("/make-server-fb86b8a8/messages/:id/read", async (c) => {
  try {
    const userId = await verifyAuth(c);
    if (!userId) return c.json({ error: "Unauthorized" }, 401);

    const id = c.req.param('id');
    const msg = await kv.get(id);
    if (msg) {
      msg.read = true;
      await kv.set(id, msg);
    }
    return c.json({ success: true });
  } catch (error) {
    console.log("Error marking message read:", error);
    return c.json({ error: "Fehler" }, 500);
  }
});

app.get("/make-server-fb86b8a8/hortner/messages/:klasse", async (c) => {
  try {
    const klasse = c.req.param('klasse');
    const allMessages = await kv.getByPrefix("message:");
    const filtered = allMessages.filter((m: any) => !m.klasse || m.klasse === klasse);
    return c.json({ messages: filtered });
  } catch (error) {
    console.log("Error loading hortner messages:", error);
    return c.json({ messages: [] });
  }
});

// ========== TIME RESTRICTIONS ==========

app.get("/make-server-fb86b8a8/admin/time-restrictions", async (c) => {
  try {
    const settings = await kv.get("time_restrictions");
    return c.json({
      settings: settings || {
        enabled: true,
        blockStartHour: 12,
        blockEndHour: 17,
        blockWeekdaysOnly: true,
      }
    });
  } catch (error) {
    console.log("Error loading time restrictions:", error);
    return c.json({
      settings: {
        enabled: true,
        blockStartHour: 12,
        blockEndHour: 17,
        blockWeekdaysOnly: true,
      }
    });
  }
});

app.put("/make-server-fb86b8a8/admin/time-restrictions", async (c) => {
  try {
    const settings = await c.req.json();
    await kv.set("time_restrictions", settings);
    return c.json({ success: true });
  } catch (error) {
    console.log("Error saving time restrictions:", error);
    return c.json({ error: "Fehler beim Speichern" }, 500);
  }
});

Deno.serve(app.fetch);